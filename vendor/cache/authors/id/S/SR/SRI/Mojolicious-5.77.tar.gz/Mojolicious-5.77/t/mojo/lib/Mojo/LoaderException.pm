package Mojo::LoaderException;

use Mojo::Base -base;

foo {

1;
